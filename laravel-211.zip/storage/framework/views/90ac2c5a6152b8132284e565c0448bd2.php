

<?php $__env->startSection('content'); ?>
    <h1>Contacts</h1>

    <form action="<?php echo e(route('sendEmail')); ?>" method="post">
        <div>
            <label for="name">Name:</label>
            <input type="text" name="name" class="form-control">
        </div>

        <div class="mb-3">
            <label for="email">Email:</label>
            <input type="email" name="email" class="form-control">
        </div>

        <div class="mb-3">
            <label for="message">Message:</label>
            <textarea name="message" class="form-control"></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Send</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\laravel-211\resources\views/client/contacts.blade.php ENDPATH**/ ?>